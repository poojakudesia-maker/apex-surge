# Contributing to APEX SURGE

Thank you for your interest in contributing to APEX SURGE! We welcome contributions from everyone—whether it's code, documentation, bug reports, or feature ideas.

---

## 🤝 How to Contribute

### 1. **Report Bugs**
Found a bug? Please open an issue with:
- Clear description of the problem
- Steps to reproduce
- Expected vs. actual behavior
- Environment (OS, browser, Node version)

### 2. **Suggest Features**
Have an idea? Open an issue with:
- Clear feature description
- Use case & motivation
- Potential implementation notes (optional)

### 3. **Submit Code**
Ready to code? Follow this process:

#### Fork & Clone
```bash
git clone https://github.com/YOUR_USERNAME/apex-surge.git
cd apex-surge
git remote add upstream https://github.com/pooja-kudesia/apex-surge.git
```

#### Create a Branch
```bash
git checkout -b feature/your-feature-name
# or for bug fixes:
git checkout -b fix/issue-description
```

#### Make Changes
- Keep commits atomic and well-described
- Follow the code style below
- Test your changes locally

#### Push & Create PR
```bash
git push origin feature/your-feature-name
```

Then open a Pull Request on GitHub with:
- Clear title (e.g., "Add voice journal feature")
- Description of changes
- Related issue links (if applicable)
- Screenshots (for UI changes)

---

## 📋 Code Style Guidelines

### JavaScript/React
```javascript
// Use const by default, let when necessary
const MyComponent = ({ prop1, prop2 }) => {
  return (
    <div className="space-y-4">
      {/* Use descriptive names */}
      <h1 className="text-2xl font-bold text-primary-600">Title</h1>
    </div>
  );
};

export default MyComponent;
```

**Rules:**
- Use arrow functions for components
- Destructure props
- Keep components under 300 lines
- Use meaningful variable names
- Add comments for complex logic
- Use Tailwind classes (no inline styles)

### File Organization
```
src/
├── components/           # Reusable UI components
│   ├── Button.jsx
│   ├── Card.jsx
│   └── Navigation.jsx
├── pages/               # Full-page components
│   ├── Home.jsx
│   └── Profile.jsx
├── services/            # API, Firebase, Claude calls
│   ├── firebaseConfig.js
│   └── claudeAPI.js
├── hooks/               # Custom React hooks
│   └── useAuth.js
├── utils/               # Utility functions
│   └── formatters.js
└── App.jsx
```

### Naming Conventions
- **Components:** PascalCase (`MyComponent.jsx`)
- **Functions:** camelCase (`getUser()`)
- **Constants:** UPPER_SNAKE_CASE (`MAX_RETRIES`)
- **CSS Classes:** lowercase with hyphens (`text-primary-600`)

### Tailwind CSS
- Use predefined spacing scale (4px base unit)
- Use color utilities over hex values
- Use responsive prefixes (`sm:`, `md:`, `lg:`)
- Example: `<div className="px-4 py-2 sm:px-6 sm:py-3 md:px-8">`

---

## 🧪 Testing

Before submitting a PR:

```bash
# Run linter
npm run lint

# Test locally
npm start

# Build for production
npm run build
```

---

## 📖 Documentation

When adding features, please update relevant docs:
- `docs/FEATURES.md` — User-facing features
- `docs/API.md` — If modifying Claude prompts
- `docs/ARCHITECTURE.md` — If changing system design
- README.md — High-level changes

---

## 🔄 Pull Request Process

1. **Assign to yourself** and add relevant labels
2. **Link related issues** (e.g., "Fixes #123")
3. **Request review** from maintainers
4. **Address feedback** promptly
5. **Squash commits** before merge (optional but appreciated)

---

## 🎯 Development Priorities

**Current Focus:**
1. Core 8 flows (all stable)
2. Firebase optimization & scaling
3. Claude prompt refinement
4. Mobile responsiveness
5. Offline support

**Lower Priority:**
- Analytics & dashboard
- Advanced admin features
- Third-party integrations

---

## 📞 Need Help?

- 💬 **Discussion:** Open a GitHub Discussion
- 📧 **Email:** hello@apexsurge.app
- 🐛 **Bugs:** Open an Issue with "bug" label
- 💡 **Ideas:** Open an Issue with "enhancement" label

---

## 📜 License

By contributing to APEX SURGE, you agree that your contributions will be licensed under the MIT License.

---

## 🙌 Acknowledgments

Thank you to all contributors who help make APEX SURGE better!

**Happy coding! 🚀**
