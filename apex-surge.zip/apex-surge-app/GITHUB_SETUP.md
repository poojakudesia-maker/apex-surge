# 📦 Push APEX SURGE to GitHub

This guide walks you through creating and pushing the APEX SURGE repository to GitHub.

---

## 🚀 Step 1: Create GitHub Repository

1. Go to [github.com/new](https://github.com/new)
2. **Repository name:** `apex-surge`
3. **Description:** "AI-powered personal growth PWA — Transform your life across 4 dimensions"
4. **Visibility:** Public (to encourage contributions)
5. **Initialize:** Do NOT add README, .gitignore, or license (we have them)
6. Click "Create repository"

---

## 📤 Step 2: Push Code to GitHub

```bash
# Navigate to your repo
cd ~/apex-surge-app

# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit: APEX SURGE MVP with all 8 flows"

# Add remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/apex-surge.git

# Rename branch to main
git branch -M main

# Push to GitHub
git push -u origin main
```

---

## 🔐 Step 3: Set Up GitHub Secrets (For CI/CD)

Go to **Settings → Secrets and variables → Actions** and add:

```
FIREBASE_API_KEY              = your_firebase_api_key
FIREBASE_AUTH_DOMAIN          = your_project.firebaseapp.com
FIREBASE_PROJECT_ID           = your_project_id
FIREBASE_STORAGE_BUCKET       = your_project.appspot.com
FIREBASE_MESSAGING_SENDER_ID  = your_sender_id
FIREBASE_APP_ID               = your_app_id
FIREBASE_SERVICE_ACCOUNT      = (paste entire service account JSON)
CLAUDE_API_KEY                = sk-ant-...your_key...
```

---

## 🤖 Step 4: Enable GitHub Actions

1. Go to **Settings → Actions**
2. Ensure "All actions and reusable workflows" is enabled
3. Workflows (`.github/workflows/deploy.yml`) will auto-run on push to `main`

---

## 🌳 Step 5: Set Up Branch Protection (Optional but Recommended)

1. Go to **Settings → Branches**
2. Click "Add rule" under "Branch protection rules"
3. **Branch name pattern:** `main`
4. Enable:
   - ✅ Require pull request reviews before merging
   - ✅ Require status checks to pass before merging
   - ✅ Require branches to be up to date

---

## 📝 Step 6: Add Topics (For Discoverability)

Go to **Settings → General** and add topics:
- `personal-growth`
- `ai-coaching`
- `behavior-change`
- `pwa`
- `react`
- `firebase`
- `claude-ai`

---

## 🎯 Step 7: Configure Repository Homepage

1. Go to **Settings → General**
2. **Website:** https://apexsurge.app
3. **Discussions:** Enable (for community Q&A)
4. **Wiki:** Enable (for documentation)

---

## 📋 Step 8: Create Release

```bash
# Create a tag
git tag -a v1.0.0 -m "Initial release: APEX SURGE MVP"

# Push tag
git push origin v1.0.0
```

Then on GitHub:
1. Go to **Releases → Draft a new release**
2. Select tag `v1.0.0`
3. Add release notes:

```markdown
# APEX SURGE v1.0.0 — MVP Release

🚀 **Initial Release**

All 8 core flows complete and tested:
- ✅ Onboarding (Goal setting & Growth Profile)
- ✅ Daily Learning (Micro-missions with AI)
- ✅ Book Explorer (50 curated books)
- ✅ AI Coach (Chat interface)
- ✅ Roleplay Practice (Interactive scenarios)
- ✅ Growth Roadmap (8-week transformation)
- ✅ Personal Playbook (Knowledge graph)
- ✅ Weekly Review (Retrospective & planning)

**Tech Stack:**
- React 18 + Tailwind CSS
- Firebase (Firestore + Auth + Hosting)
- Claude API (Sonnet 3.5)
- Web Speech API (Audio)
- Progressive Web App (PWA)

**Cost:** $3-7/month (Claude API only)

**Live:** https://apexsurge.app
**Docs:** https://github.com/pooja-kudesia/apex-surge/tree/main/docs

Thanks to all contributors! 🙏
```

---

## 🎨 Step 9: Customize Repository (Optional)

### Create GitHub Profile Page
Create `.github/profile/README.md`:

```markdown
# Hey! 👋 Welcome to APEX SURGE

**Transform Your Life Across 4 Dimensions** 🚀

- 💼 **Career Growth** — Leadership, delegation, influence
- 🌱 **Personal Growth** — Habits, mindfulness, confidence  
- 💬 **Communication** — Persuasion, difficult conversations
- ⚡ **10X Productivity** — Focus, deep work, exponential output

**[Start Now](https://apexsurge.app) | [Documentation](docs/) | [Issues](issues)**
```

---

## 📊 Step 10: Monitor Repository

Set up:
1. **GitHub Insights → Traffic** — Track clones, page views
2. **GitHub Insights → Network** — See fork history
3. **Security → Dependabot** — Auto-update dependencies
4. **Security → Code scanning** — Auto-scan for vulnerabilities

---

## 🔄 Continuous Deployment Workflow

Every push to `main`:
1. ✅ Code is linted
2. ✅ Tests run (npm test)
3. ✅ Build succeeds (npm run build)
4. ✅ Deployed to Firebase Hosting
5. ✅ Live at https://apex-surge-[project-id].web.app

---

## 📢 Promote Your Repository

### Share on:
- 🐦 **Twitter:** "Just launched APEX SURGE — AI personal growth PWA. All 8 flows built. Open source. Free to run. GitHub: ..."
- 📰 **Dev.to:** Write a launch post
- 🔗 **Product Hunt:** Submit on launch day
- 💬 **Reddit:** r/PersonalProductivity, r/reactjs, r/Firebase
- 📧 **Newsletter:** Tell your subscribers

### Badge for README:
```markdown
[![GitHub Stars](https://img.shields.io/github/stars/pooja-kudesia/apex-surge.svg?style=social)](https://github.com/pooja-kudesia/apex-surge)
[![GitHub Forks](https://img.shields.io/github/forks/pooja-kudesia/apex-surge.svg?style=social)](https://github.com/pooja-kudesia/apex-surge)
```

---

## ❓ Troubleshooting

### "fatal: not a git repository"
```bash
git init
git add .
git commit -m "Initial commit"
```

### "Permission denied" when pushing
```bash
# Use SSH instead of HTTPS
git remote remove origin
git remote add origin git@github.com:YOUR_USERNAME/apex-surge.git
git push -u origin main
```

### Workflow not running
- ✅ Check `.github/workflows/deploy.yml` exists
- ✅ Verify GitHub Actions is enabled in Settings
- ✅ Check branch is named `main` (not `master`)
- ✅ Verify all secrets are set

---

## 🎉 Congratulations!

Your APEX SURGE repository is now live and ready for contributions!

**Next Steps:**
1. Test the GitHub workflow by making a small change
2. Share with friends & potential contributors
3. Respond to issues and pull requests
4. Build amazing features together! 🚀

---

**Questions?** Open an issue or email hello@apexsurge.app
