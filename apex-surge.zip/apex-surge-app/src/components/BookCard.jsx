import React, { useState } from 'react';
import { FiBook, FiStar, FiArrowRight } from 'react-icons/fi';

/**
 * BookCard Component
 * 
 * Displays a single book with:
 * - Cover image
 * - Title & author
 * - Rating
 * - Category badge
 * - CTA to view details
 * 
 * @param {Object} book - Book data from Firestore
 * @param {Function} onSelect - Callback when book is clicked
 */
const BookCard = ({ book, onSelect }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async () => {
    setIsLoading(true);
    try {
      onSelect(book);
    } catch (error) {
      console.error('Error selecting book:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div 
      onClick={handleClick}
      className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer overflow-hidden"
    >
      {/* Cover Image */}
      <div className="relative h-48 bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center">
        {book.cover ? (
          <img 
            src={book.cover} 
            alt={book.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <FiBook className="w-16 h-16 text-primary-400" />
        )}
        
        {/* Category Badge */}
        <div className="absolute top-2 right-2 bg-primary-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
          {book.category}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Title */}
        <h3 className="font-display text-lg font-bold text-gray-900 line-clamp-2">
          {book.title}
        </h3>

        {/* Author */}
        <p className="text-sm text-gray-600 mb-3">
          by {book.author}
        </p>

        {/* Rating & Reviews */}
        <div className="flex items-center gap-2 mb-4">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <FiStar
                key={i}
                className={`w-4 h-4 ${
                  i < Math.round(book.rating)
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="text-xs text-gray-600">
            {book.rating} ({book.reviews} reviews)
          </span>
        </div>

        {/* Description */}
        <p className="text-sm text-gray-700 line-clamp-2 mb-4">
          {book.description}
        </p>

        {/* Relevance Score */}
        <div className="grid grid-cols-2 gap-2 mb-4 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Career:</span>
            <span className="font-semibold text-primary-600">
              {Math.round(book.relevantFor.career * 100)}%
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Personal:</span>
            <span className="font-semibold text-accent-600">
              {Math.round(book.relevantFor.personal * 100)}%
            </span>
          </div>
        </div>

        {/* CTA Button */}
        <button
          onClick={handleClick}
          disabled={isLoading}
          className={`w-full py-2 px-4 rounded-lg font-semibold flex items-center justify-center gap-2 transition-colors ${
            isLoading
              ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
              : 'bg-primary-500 text-white hover:bg-primary-600'
          }`}
        >
          {isLoading ? 'Loading...' : (
            <>
              View Details
              <FiArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default BookCard;
