/**
 * Claude API Service
 * 
 * Wrapper around Anthropic Claude API with prompt templates for:
 * - Book matching
 * - Summary generation
 * - Experiment creation
 * - Personalization
 * - AI coaching
 */

const CLAUDE_API_URL = 'https://api.anthropic.com/v1/messages';
const CLAUDE_MODEL = 'claude-3-5-sonnet-20241022';
const MAX_TOKENS = 2048;

/**
 * Call Claude API with streaming support
 */
export async function callClaude(systemPrompt, userMessage) {
  const apiKey = process.env.REACT_APP_CLAUDE_API_KEY;
  
  if (!apiKey) {
    throw new Error('Claude API key not configured');
  }

  try {
    const response = await fetch(CLAUDE_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: CLAUDE_MODEL,
        max_tokens: MAX_TOKENS,
        system: systemPrompt,
        messages: [
          {
            role: 'user',
            content: userMessage,
          },
        ],
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Claude API error: ${error.message}`);
    }

    const data = await response.json();
    return data.content[0].text;
  } catch (error) {
    console.error('Claude API call failed:', error);
    throw error;
  }
}

/**
 * Match books to user based on goals and challenges
 */
export async function matchBooksToUser(userGoals, challenge, books) {
  const systemPrompt = `You are an AI book recommendation engine for APEX SURGE.
Your task is to match books to a user's goals and challenges.

Return a JSON array with top 5 book recommendations, each with:
- bookId
- title
- author
- matchScore (0-100)
- reason (why this book matches their goal)

Example format:
[
  {
    "bookId": "radical-candor",
    "title": "Radical Candor",
    "author": "Kim Malone Scott",
    "matchScore": 95,
    "reason": "Directly addresses communication and feedback challenges"
  }
]`;

  const userMessage = `User Goals: ${userGoals.join(', ')}
Challenge: ${challenge}

Available Books:
${books.map(b => `- ${b.title} by ${b.author} (${b.category}): ${b.description}`).join('\n')}

Please recommend the top 5 most relevant books.`;

  const response = await callClaude(systemPrompt, userMessage);
  
  try {
    // Extract JSON from response
    const jsonMatch = response.match(/\[[\s\S]*\]/);
    return JSON.parse(jsonMatch[0]);
  } catch (error) {
    console.error('Failed to parse book recommendations:', error);
    return [];
  }
}

/**
 * Generate audio-friendly book summary
 */
export async function generateBookSummary(book) {
  const systemPrompt = `You are an expert book summarizer for APEX SURGE.
Generate a concise, audio-friendly summary of a book that:
- Captures key ideas (3-5 main points)
- Is optimized for text-to-speech (natural language, short sentences)
- Takes 5-8 minutes to listen to
- Ends with actionable insights

Format your response as JSON:
{
  "summary": "The main narrative and key points...",
  "keyPoints": ["Point 1", "Point 2", "Point 3"],
  "actionableInsights": ["Action 1", "Action 2"],
  "estimatedReadingTime": "8 minutes"
}`;

  const userMessage = `Please summarize this book for audio consumption:

Title: ${book.title}
Author: ${book.author}
Category: ${book.category}
Description: ${book.description}

Make it engaging and optimized for listening.`;

  const response = await callClaude(systemPrompt, userMessage);
  
  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    return JSON.parse(jsonMatch[0]);
  } catch (error) {
    console.error('Failed to parse book summary:', error);
    return {
      summary: response,
      keyPoints: [],
      actionableInsights: [],
      estimatedReadingTime: '8 minutes',
    };
  }
}

/**
 * Generate personalized experiment based on book idea
 */
export async function generateExperiment(bookIdea, userGoal, userContext) {
  const systemPrompt = `You are an AI coach designing behavior-change experiments for APEX SURGE.
Create a concrete, real-world experiment that:
- Is 5-15 minutes to complete
- Can be done today/tomorrow
- Tests the book idea in practice
- Has clear success criteria
- Is low-risk and achievable

Return JSON format:
{
  "title": "Experiment name",
  "description": "What the user will do",
  "steps": ["Step 1", "Step 2", "Step 3"],
  "successCriteria": "How to know if it worked",
  "timeNeeded": "minutes",
  "difficulty": "easy|medium|hard"
}`;

  const userMessage = `Book Idea: ${bookIdea}
User Goal: ${userGoal}
User Context: ${userContext}

Design a specific, actionable experiment they can try immediately.`;

  const response = await callClaude(systemPrompt, userMessage);
  
  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    return JSON.parse(jsonMatch[0]);
  } catch (error) {
    console.error('Failed to parse experiment:', error);
    return {
      title: 'Try the idea',
      description: response,
      steps: [],
      successCriteria: 'See if it works',
      timeNeeded: '15',
      difficulty: 'medium',
    };
  }
}

/**
 * AI Coach conversation
 */
export async function coachChat(userMessage, userHistory, userBooks, userGoals) {
  const systemPrompt = `You are APEX SURGE's AI Coach - a personal growth mentor.
Your role is to:
- Help users apply book ideas to their lives
- Track progress on experiments and goals
- Provide encouragement and insights
- Ask clarifying questions to deepen understanding
- Reference books they've learned from

User's Goals: ${userGoals.join(', ')}
Books Learned: ${userBooks.join(', ')}

Be conversational, warm, and genuinely helpful. Keep responses under 200 words.`;

  const conversationHistory = userHistory
    .slice(-5) // Last 5 messages for context
    .map(msg => ({
      role: msg.role,
      content: msg.content,
    }));

  conversationHistory.push({
    role: 'user',
    content: userMessage,
  });

  try {
    const response = await fetch(CLAUDE_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.REACT_APP_CLAUDE_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: CLAUDE_MODEL,
        max_tokens: MAX_TOKENS,
        system: systemPrompt,
        messages: conversationHistory,
      }),
    });

    if (!response.ok) {
      throw new Error('Coach API error');
    }

    const data = await response.json();
    return data.content[0].text;
  } catch (error) {
    console.error('Coach chat failed:', error);
    throw error;
  }
}

/**
 * Generate weekly review summary
 */
export async function generateWeeklyReview(weeklyData) {
  const systemPrompt = `You are a reflective coach helping users learn from their week.
Analyze their weekly data and provide:
- What went well (celebrations)
- Key learnings
- Patterns noticed
- Suggestions for next week
- A motivational message

Be specific, warm, and encouraging. Keep it under 300 words.`;

  const userMessage = `Weekly Summary:
Learned: ${weeklyData.learned.join(', ')}
Completed Experiments: ${weeklyData.experimentsCompleted}
Successes: ${weeklyData.successes}
Challenges: ${weeklyData.challenges}
Daily Score: ${weeklyData.dailyScore}

Create a personalized weekly review.`;

  const response = await callClaude(systemPrompt, userMessage);
  return response;
}

/**
 * Estimate API costs
 */
export function estimateTokenCost(inputTokens, outputTokens) {
  // Claude 3.5 Sonnet pricing (as of 2024)
  const inputCost = (inputTokens / 1000000) * 3; // $3 per 1M input tokens
  const outputCost = (outputTokens / 1000000) * 15; // $15 per 1M output tokens
  
  return {
    inputTokens,
    outputTokens,
    totalTokens: inputTokens + outputTokens,
    estimatedCost: (inputCost + outputCost).toFixed(4),
  };
}

export default {
  callClaude,
  matchBooksToUser,
  generateBookSummary,
  generateExperiment,
  coachChat,
  generateWeeklyReview,
  estimateTokenCost,
};
