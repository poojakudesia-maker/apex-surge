# 🗄️ APEX SURGE Firestore Schema

Complete Firestore database structure for APEX SURGE PWA.

---

## Collections Overview

```
apex-surge-db/
├── users/{userId}
├── books/{bookId}
├── summaries/{bookId}
├── userProgress/{userId}/daily/{date}
├── experiments/{userId}/{experimentId}
├── userPlaybook/{userId}
└── learningPaths/{userId}/{pathId}
```

---

## 1. `users/{userId}` — User Profiles

**Purpose:** Store user account, goals, preferences, and growth profile.

**Schema:**
```javascript
{
  userId: "user123",                    // Firebase Auth UID
  email: "user@example.com",
  name: "Sarah Chen",
  avatar: "https://...",
  createdAt: Timestamp,
  updatedAt: Timestamp,
  
  // Onboarding Data
  goals: ["Career growth", "Better communication"],
  challenge: "Struggle to lead effectively",
  timeCommitment: "30 min/day",
  learningStyle: "visual",
  
  // Growth Profile (AI-generated)
  growthProfile: {
    lifePath: 4,
    expressionNumber: 1,
    personalityNumber: 7,
    luckyNumbers: [1, 4, 7, 10],
    primaryDimension: "career",      // career | personal | communication | productivity
    secondaryDimensions: ["communication", "personal"],
  },
  
  // Progress Tracking
  streak: 7,                          // Days of consistent activity
  totalScore: 1250,
  weeklyScore: 180,
  level: 5,                           // Growth level (1-10)
  
  // Preferences
  preferences: {
    audioEnabled: true,
    notificationsEnabled: true,
    dailyReminderTime: "07:00",
    theme: "light",                   // light | dark
  },
  
  // Subscription
  plan: "free",                        // free | premium | lifetime
  planStartDate: Timestamp,
  planExpiry: Timestamp,
}
```

**Indexes:**
- `createdAt` (ascending)
- `plan` (ascending)
- `totalScore` (descending)

---

## 2. `books/{bookId}` — Book Metadata

**Purpose:** Store information about the 50 curated books.

**Schema:**
```javascript
{
  bookId: "radical-candor-kim-scott",
  title: "Radical Candor",
  author: "Kim Malone Scott",
  isbn: "1250235340",
  description: "Learn to be more effective...",
  cover: "https://images.example.com/radical-candor.jpg",
  
  // Categorization
  category: "Leadership",              // Leadership | Productivity | Communication | etc.
  keyTopics: ["feedback", "communication", "leadership"],
  difficulty: "intermediate",          // beginner | intermediate | advanced
  readingTime: 8,                      // hours
  
  // Relevance Scoring (for book matching)
  relevantFor: {
    career: 0.95,
    personal: 0.60,
    communication: 0.88,
    productivity: 0.50,
  },
  
  // Metadata
  publishedDate: "2017-09-19",
  rating: 4.5,
  reviews: 1250,
  language: "en",
  
  // System Fields
  createdAt: Timestamp,
  summarized: true,                   // Whether Claude summary exists
  summaryTokens: 450,                 // Tokens used in summary
}
```

**Indexes:**
- `category` (ascending)
- `difficulty` (ascending)
- `relevantFor.career` (descending)

---

## 3. `summaries/{bookId}` — Book Summaries

**Purpose:** Store AI-generated book summaries for fast retrieval (cached).

**Schema:**
```javascript
{
  bookId: "radical-candor-kim-scott",
  title: "Radical Candor",
  
  // Generated Content
  summary: "Radical Candor is a guide to being a great boss...",
  keyPoints: [
    "Care personally while challenging directly",
    "Give immediate, specific feedback",
    "Listen to feedback about yourself",
  ],
  actionableInsights: [
    "Schedule 1:1 meetings for honest feedback",
    "Create psychological safety first",
  ],
  
  // For Audio
  audioText: "Radical Candor is a guide...",  // Optimized for TTS
  estimatedAudioLength: 420,           // seconds
  
  // Experiment Seeds
  experimentIdea: "Have one difficult conversation...",
  
  // Application Seed
  applicationTemplate: "In your role as...",
  
  // Cost & Usage
  generatedAt: Timestamp,
  inputTokens: 1200,
  outputTokens: 450,
  estimatedCost: 0.032,                // USD
  useCount: 15,                        // Times used by users
}
```

**TTL Policy:** Keep indefinitely (one-time generation cost).

---

## 4. `userProgress/{userId}/daily/{date}` — Daily Activity

**Purpose:** Track daily learning and experimentation.

**Purpose:** Track daily learning and experimentation.

**Schema:**
```javascript
{
  userId: "user123",
  date: "2026-08-30",                  // ISO 8601
  
  // Learning Activity
  learned: {
    bookId: "radical-candor-kim-scott",
    keyIdea: "Care personally while challenging",
    timeSpent: 15,                     // minutes
    audioUsed: true,
    completedAt: Timestamp,
  },
  
  // Experiment Activity
  experimentCompleted: {
    experimentId: "exp-2026-08-30",
    experimentType: "difficult-conversation",
    result: "success",                 // success | partial | failed
    reflection: "Had better conversation than usual",
    timeSpent: 12,                     // minutes
    completedAt: Timestamp,
  },
  
  // Scores
  dailyScore: 45,
  bonusPoints: 5,                      // Streak bonus, perfect day, etc.
  
  // Mood & Energy
  moodBefore: 6,                       // 1-10 scale
  moodAfter: 8,
  energyLevel: 7,
  
  createdAt: Timestamp,
  updatedAt: Timestamp,
}
```

**Indexes:**
- `userId, date` (ascending)
- `date` (descending)

---

## 5. `experiments/{userId}/{experimentId}` — Experiment Tracking

**Purpose:** Store detailed experiment progress and results.

**Schema:**
```javascript
{
  userId: "user123",
  experimentId: "exp-2026-08-30",
  
  // Experiment Info
  title: "Have a difficult conversation",
  description: "Schedule time to give feedback...",
  basedOnBooks: ["radical-candor-kim-scott"],
  basedOnLearning: "Care personally + challenge directly",
  
  // Status
  status: "completed",                // pending | in-progress | completed | failed
  startedAt: Timestamp,
  completedAt: Timestamp,
  daysToComplete: 1,
  
  // Execution
  context: "Team meeting feedback",
  steps: [
    "Scheduled 1:1 meeting",
    "Prepared specific feedback",
    "Delivered with empathy",
  ],
  
  // Results
  resultType: "success",               // success | partial | failed | learning
  reflection: "Went better than expected. She appreciated the honesty.",
  lessonsLearned: ["Preparation is key", "Tone matters most"],
  
  // Scoring
  experimentScore: 85,                 // 1-100
  impactRating: 9,                     // 1-10 self-reported
  
  // Follow-up
  followUp: "Plan second conversation",
  nextExperimentTopic: "deeper-feedback",
  
  createdAt: Timestamp,
  updatedAt: Timestamp,
}
```

**Indexes:**
- `userId, status` (ascending)
- `completedAt` (descending)

---

## 6. `userPlaybook/{userId}` — Personal Knowledge Graph

**Purpose:** Curated collection of principles and insights learned.

**Schema:**
```javascript
{
  userId: "user123",
  
  // Personal Principles
  principles: [
    {
      id: "principle-1",
      title: "Care Personally",
      description: "Show genuine interest in team members...",
      source: "Radical Candor",
      createdAt: Timestamp,
      strength: 5,                     // 1-5 stars based on experiments
    },
  ],
  
  // Key Insights
  insights: [
    {
      id: "insight-1",
      title: "Feedback needs to be immediate",
      description: "Delayed feedback loses effectiveness...",
      relatedPrinciples: ["principle-1"],
      validatedBy: ["exp-2026-08-30"],  // Experiments that proved it
      createdAt: Timestamp,
    },
  ],
  
  // Best Practices
  bestPractices: [
    {
      id: "practice-1",
      title: "Weekly 1:1 meetings",
      category: "leadership",
      steps: ["Schedule early", "Prepare questions", "Listen more"],
      source: "Radical Candor",
      successRate: 0.95,               // Based on experiments
      createdAt: Timestamp,
    },
  ],
  
  // Connections (Knowledge Graph)
  connections: [
    {
      from: "principle-1",
      to: "principle-2",
      relationship: "complements",
    },
  ],
  
  // Stats
  totalPrinciples: 8,
  totalInsights: 15,
  totalPractices: 12,
  
  lastUpdated: Timestamp,
}
```

---

## 7. `learningPaths/{userId}/{pathId}` — 8-Week Roadmap

**Purpose:** Store personalized 8-week transformation journey.

**Schema:**
```javascript
{
  userId: "user123",
  pathId: "lp-2026-09-01",
  
  // Overview
  title: "Become an Effective Leader",
  startDate: "2026-09-01",
  endDate: "2026-10-26",               // 8 weeks
  dimension: "career",                 // Primary growth area
  
  // Weekly Breakdown
  weeks: [
    {
      week: 1,
      title: "Master Radical Candor",
      goals: ["Learn feedback framework", "Prepare first conversation"],
      bookIds: ["radical-candor-kim-scott"],
      experiments: ["exp-week1-1", "exp-week1-2"],
      progressScore: 100,              // Week 1 completed
    },
    // ... weeks 2-8
  ],
  
  // Progress
  currentWeek: 2,
  completedWeeks: 1,
  progressPercentage: 12.5,
  
  // Outcomes (Week by week)
  outcomes: [
    {
      week: 1,
      skillsGained: ["feedback-giving", "empathy"],
      habitsFormed: 1,
      confidence: 6,
    },
  ],
  
  // Final Review
  finalReview: null,                   // Filled at end of 8 weeks
  
  createdAt: Timestamp,
  updatedAt: Timestamp,
}
```

---

## Security Rules

**Firestore Security Rules:**
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can only access their own data
    match /users/{userId} {
      allow read, write: if request.auth.uid == userId;
    }

    // Books are public read-only
    match /books/{bookId} {
      allow read: if request.auth != null;
      allow write: if false;
    }

    // Summaries are public read-only
    match /summaries/{bookId} {
      allow read: if request.auth != null;
      allow write: if false;
    }

    // User progress is private
    match /userProgress/{userId}/{document=**} {
      allow read, write: if request.auth.uid == userId;
    }

    // User experiments are private
    match /experiments/{userId}/{document=**} {
      allow read, write: if request.auth.uid == userId;
    }

    // User playbook is private
    match /userPlaybook/{userId} {
      allow read, write: if request.auth.uid == userId;
    }

    // Learning paths are private
    match /learningPaths/{userId}/{document=**} {
      allow read, write: if request.auth.uid == userId;
    }
  }
}
```

---

## Backup & Retention Policy

| Collection | Retention | Backup Frequency |
|-----------|-----------|-----------------|
| users | Forever | Daily |
| books | Forever | Weekly |
| summaries | Forever | Weekly |
| userProgress | Forever | Daily |
| experiments | Forever | Daily |
| userPlaybook | Forever | Daily |
| learningPaths | 1 year after completion | Weekly |

---

## Cost Estimates (MVP - 100 Users)

| Operation | Read Cost | Write Cost | Monthly |
|-----------|-----------|-----------|---------|
| Daily check-in | 100 reads/day | 100 writes/day | ~$0.50 |
| Weekly summary | 25 reads/week | 25 writes/week | ~$0.15 |
| Monthly review | 10 reads/month | 10 writes/month | ~$0.05 |
| **Total** | - | - | **~$0.70/month** |

**Note:** Firebase free tier includes 50K reads, 20K writes, 20K deletes/day. Easily covers 100-1000 users.

---

## Migration & Seeding

**Seed 50 books:**
```bash
firebase firestore:import books-seed.json
```

**See** `firebase/books-seed.json` for sample data.

---

## Optimization Tips

1. **Pagination:** Load userProgress in chunks (e.g., 7 days at a time)
2. **Caching:** Cache book summaries client-side (stored forever)
3. **Indexes:** Create indexes for queries on `userId` + `date`
4. **Denormalization:** Store bookTitle in experiments to avoid lookups

---

**Questions?** Open an issue on GitHub or email hello@apexsurge.app
