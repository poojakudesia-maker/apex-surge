# 🚀 APEX SURGE — Quick Start Guide

Get APEX SURGE running locally in 10 minutes.

---

## ⚡ Prerequisites

- Node.js 16+ ([download](https://nodejs.org))
- npm 8+
- A code editor (VS Code recommended)
- A Firebase account (free at [firebase.google.com](https://firebase.google.com))
- An Anthropic API key (free at [console.anthropic.com](https://console.anthropic.com))

---

## 🔧 Step 1: Clone & Install (2 min)

```bash
# Clone repository
git clone https://github.com/pooja-kudesia/apex-surge.git
cd apex-surge

# Install dependencies
npm install
```

---

## 🔑 Step 2: Set Up Firebase (3 min)

### Create Firebase Project
1. Go to [firebase.google.com](https://firebase.google.com)
2. Click "Get Started"
3. Create new project: `apex-surge`
4. Skip Google Analytics (not needed)
5. Go to Project Settings → Service Accounts
6. Copy your Firebase configuration

### Set Up Firestore Database
1. Go to **Firestore Database** in Firebase Console
2. Click "Create Database"
3. Start in **Production Mode**
4. Location: Select your region (e.g., `us-east1`)
5. Click "Enable"

### Create Firebase Config File
In your project root, create `src/services/firebaseConfig.js`:

```javascript
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
  storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.REACT_APP_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
```

---

## 🔐 Step 3: Set Up Environment Variables (2 min)

```bash
# Copy example env file
cp .env.example .env.local
```

Edit `.env.local`:

```env
# Firebase
REACT_APP_FIREBASE_API_KEY=your_firebase_api_key
REACT_APP_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
REACT_APP_FIREBASE_PROJECT_ID=your_project_id
REACT_APP_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
REACT_APP_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
REACT_APP_FIREBASE_APP_ID=your_app_id

# Anthropic Claude API
REACT_APP_CLAUDE_API_KEY=sk-ant-...your_api_key_here...

# App
REACT_APP_ENV=development
```

**To find your Firebase credentials:**
1. Firebase Console → Project Settings
2. Click "Web" app
3. Copy the `firebaseConfig` object

---

## 🤖 Step 4: Set Up Claude API Key (1 min)

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Click "API Keys" in sidebar
3. Create new key (copy immediately)
4. Paste into `.env.local`: `REACT_APP_CLAUDE_API_KEY=sk-ant-...`

---

## ▶️ Step 5: Run Development Server (1 min)

```bash
npm start
```

The app opens at **http://localhost:3000**

---

## 📱 Step 6: Test the App

### Try These Actions:
1. **Sign Up** → Create an account
2. **Onboarding** → Set your goals, challenge, time commitment
3. **Explore Books** → Browse the 50 curated books
4. **Read a Summary** → Click any book → "Get Summary" → Listen with audio
5. **Daily Mission** → Start today's learning mission
6. **AI Coach** → Chat with the coach
7. **Growth Roadmap** → See your 8-week transformation plan

---

## 🔧 Common Development Commands

```bash
# Start development server
npm start

# Build for production
npm run build

# Run tests
npm test

# Lint code
npm run lint

# Analyze bundle size
npm run analyze
```

---

## 🚨 Troubleshooting

### "Firebase initialization failed"
- ✅ Check `.env.local` has all Firebase credentials
- ✅ Verify Firestore Database is created (green checkmark)
- ✅ Check security rules allow reads/writes (see `firebase/firestore-schema.md`)

### "Claude API key error"
- ✅ Verify key starts with `sk-ant-`
- ✅ Check key isn't expired or revoked
- ✅ Ensure `REACT_APP_CLAUDE_API_KEY` in `.env.local`

### "Web Speech API not working"
- ✅ Use Chrome, Edge, or Safari (Firefox has limited support)
- ✅ Check browser allows microphone access
- ✅ Verify `REACT_APP_ENABLE_AUDIO=true` in `.env.local`

### "Port 3000 already in use"
```bash
# Use different port
PORT=3001 npm start
```

### Blank page on load
- ✅ Open browser DevTools (F12) → Console
- ✅ Check for error messages
- ✅ Clear browser cache (Ctrl+Shift+Delete)

---

## 📚 Next Steps

1. **Understand Architecture:** Read `docs/ARCHITECTURE.md`
2. **Explore Features:** Read `docs/FEATURES.md`
3. **Claude Prompts:** Read `docs/API.md`
4. **Make Changes:** Start editing `src/components/`
5. **Test on Mobile:** Use `ngrok` to expose localhost, test on phone

---

## 🚀 Deploy to Firebase Hosting

```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login to Firebase
firebase login

# Deploy
firebase deploy
```

App is now live at: `https://apex-surge-PROJECT_ID.web.app`

---

## 📞 Need Help?

- 💬 GitHub Issues: [github.com/pooja-kudesia/apex-surge/issues](https://github.com/pooja-kudesia/apex-surge/issues)
- 📧 Email: hello@apexsurge.app
- 🌐 Website: apexsurge.app

---

**You're all set! Happy coding! 🎉**
