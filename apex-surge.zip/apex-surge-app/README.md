# 🚀 APEX SURGE — Transform Your Life Across 4 Dimensions

**An AI-powered personal growth PWA that turns book knowledge into behavior change.**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![React](https://img.shields.io/badge/React-18.2-blue?logo=react)](https://react.dev)
[![Firebase](https://img.shields.io/badge/Firebase-Latest-orange?logo=firebase)](https://firebase.google.com)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.3-blue?logo=tailwindcss)](https://tailwindcss.com)
[![PWA](https://img.shields.io/badge/PWA-Ready-green)](https://web.dev/progressive-web-apps/)

---

## 📱 What is APEX SURGE?

APEX SURGE is a **behavior-change app** for people who read books but struggle to apply what they learn. Unlike content consumption apps (like Headway), APEX SURGE closes the **knowledge-to-action gap** through:

- 📚 **AI Book Matching** — Claude recommends books aligned to *your* goals
- 🎯 **Daily Learning Missions** — 5-15 min micro-lessons with personalized experiments
- 🔊 **Audio Learning** — Web Speech API turns book ideas into natural speech
- 🧪 **Real-World Experiments** — Apply concepts in 5-15 min real-world tests
- 📊 **Progress Tracking** — 8-week transformation roadmap with weekly reviews
- 🤖 **AI Coach** — Conversational guidance grounded in your learned books
- 🎭 **Roleplay Practice** — Interactive scenarios to build confidence
- 📖 **Personal Playbook** — Your curated knowledge graph of principles & insights

**4 Growth Dimensions:**
- 💼 **Career Growth** — Leadership, delegation, influence
- 🌱 **Personal Growth** — Habits, mindfulness, confidence
- 💬 **Communication** — Persuasion, difficult conversations, authenticity
- ⚡ **10X Productivity** — Focus, deep work, exponential output

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | React 18 + Tailwind CSS |
| **Backend** | Firebase (Firestore + Auth + Hosting) |
| **AI** | Claude API (Sonnet 3.5) |
| **Audio** | Web Speech API (browser-native, free) |
| **PWA** | Service Worker + Manifest |
| **Hosting** | Firebase Hosting (free tier) |

---

## 💰 Cost Structure (MVP)

| Component | Monthly Cost |
|-----------|---|
| Claude API | $3–7 (50–100 book summaries) |
| Web Speech API | $0 (browser-native) |
| Firebase | $0 (free tier) |
| Hosting | $0 (Firebase) |
| **TOTAL** | **$3–7/month** |

**Scales:** 100 users → ~$5/mo | 1,000 users → ~$20/mo

---

## 🚀 Quick Start

### Prerequisites
- Node.js 16+
- npm or yarn
- Firebase account (free tier)
- Anthropic API key (Claude)

### 1. Clone & Install
```bash
git clone https://github.com/pooja-kudesia/apex-surge.git
cd apex-surge
npm install
```

### 2. Set Up Environment
```bash
cp .env.example .env.local
```

Add to `.env.local`:
```
REACT_APP_FIREBASE_API_KEY=xxx
REACT_APP_FIREBASE_PROJECT_ID=xxx
REACT_APP_FIREBASE_MESSAGING_SENDER_ID=xxx
REACT_APP_FIREBASE_APP_ID=xxx
REACT_APP_CLAUDE_API_KEY=xxx
```

### 3. Create Firebase Project
```bash
firebase login
firebase init
```

### 4. Run Locally
```bash
npm start
# Opens http://localhost:3000
```

### 5. Build & Deploy
```bash
npm run build
firebase deploy
```

---

## 📂 Project Structure

```
apex-surge/
├── public/
│   ├── index.html
│   ├── manifest.json          (PWA manifest)
│   └── icon-192x192.png       (PWA icon)
├── src/
│   ├── App.jsx                (Main component)
│   ├── index.css              (Tailwind imports)
│   ├── components/
│   │   ├── Navigation.jsx     (Bottom nav: Today, Explore, Growth, Playbook, Coach)
│   │   ├── OnboardingFlow.jsx (Goal setting, challenge, learning style)
│   │   ├── DailyMission.jsx   (Learn → Apply → Experiment → Diagnosis)
│   │   ├── BookExplorer.jsx   (Browse 50 curated books)
│   │   ├── AICoach.jsx        (Chat interface)
│   │   ├── RoleplayPractice.jsx (Interactive scenarios)
│   │   ├── GrowthRoadmap.jsx  (8-week transformation)
│   │   ├── PersonalPlaybook.jsx (Knowledge graph)
│   │   └── WeeklyReview.jsx   (Retrospective + planning)
│   ├── pages/
│   │   ├── Home.jsx
│   │   ├── UserProfile.jsx
│   │   └── Settings.jsx
│   ├── services/
│   │   ├── firebaseConfig.js  (Firebase init)
│   │   ├── claudeAPI.js       (Claude prompt templates)
│   │   ├── audioService.js    (Web Speech API wrapper)
│   │   └── bookDatabase.js    (50 curated books)
│   ├── hooks/
│   │   ├── useAuth.js
│   │   ├── useFirestore.js
│   │   └── useAudio.js
│   ├── utils/
│   │   ├── numerology.js      (Lucky number calculations)
│   │   ├── dateUtils.js
│   │   └── formatters.js
│   └── data/
│       └── 50-curated-books.json
├── firebase/
│   ├── firestore-schema.md    (Firestore collections structure)
│   ├── security-rules.json    (Firestore security rules)
│   └── indexes.json           (Firestore indexes)
├── docs/
│   ├── API.md                 (Claude API prompts)
│   ├── ARCHITECTURE.md        (System design)
│   ├── DEPLOYMENT.md          (Firebase setup)
│   └── FEATURES.md            (All 8 flows documented)
├── .gitignore
├── package.json
├── tailwind.config.js
├── postcss.config.js
├── .env.example
└── README.md
```

---

## 🎯 8 Core Flows

### 1. **Onboarding** 
User sets goals, challenges, time commitment → AI builds personalized Growth Profile

### 2. **Daily Learning**
- Receive micro-mission (5-15 min)
- Learn key idea from relevant book
- Personalize to user's goal
- Get AI diagnosis of barriers
- Create + run 5-min experiment

### 3. **Book Explorer**
Browse 50 curated books → Read book details → Quiz → Get personalized application plan

### 4. **AI Coach**
Chat interface grounded in user's books, experiments, and progress

### 5. **Roleplay Practice**
Interactive scenarios (e.g., "difficult conversation with your boss") → Real-time feedback

### 6. **Growth Roadmap**
8-week transformation calendar → Weekly missions → Progress rings

### 7. **Personal Playbook**
Auto-generated knowledge graph: Principles → Insights → Experiments → Best Practices

### 8. **Weekly Review**
Learned → Applied → Changed → Failed → AI summary → Next week's plan

---

## 📚 50 Curated Books

**Categories:** Leadership (10) | Productivity (8) | Communication (8) | Confidence (7) | Money (6) | Relationships (6) | Mindfulness (5) | Health (4) | Decision Making (5) | Creativity (3) | Personal Development (6)

See `src/data/50-curated-books.json` for full list with metadata.

---

## 🔐 Firebase Firestore Schema

### Collections:
- `users/{userId}` — Profile, goals, challenge, scores
- `books/{bookId}` — Metadata, summaries, relevance scores
- `summaries/{bookId}` — Generated book summaries, key points
- `userProgress/{userId}/daily/{date}` — Daily activity & scores
- `experiments/{userId}/{experimentId}` — Experiment tracking
- `userPlaybook/{userId}` — Principles, insights, best practices

See `firebase/firestore-schema.md` for detailed structure.

---

## 🤖 Claude API Integration

APEX SURGE uses 5 main Claude prompts:

1. **matchBooksToUser()** — Recommend books based on goals
2. **generateBookSummary()** — Create audio-friendly summaries
3. **personalizeSummary()** — Reframe for user's specific goal
4. **generateExperiment()** — Design 5-15 min real-world test
5. **generatePersonalApplication()** — Create action plan

See `docs/API.md` for full prompt templates.

---

## 🔊 Audio Features

Uses **Web Speech API** (100% free, browser-native):
- Text-to-speech for book summaries
- Speech-to-text for voice journals
- No TTS service needed (no API calls)

---

## 📱 PWA Features

- ✅ Install on iOS/Android home screen
- ✅ Works offline (Service Worker)
- ✅ Background sync
- ✅ Push notifications
- ✅ Responsive design (mobile-first)

See `docs/DEPLOYMENT.md` for PWA setup.

---

## 🌟 Numerological Alignment

Built by **Pooja Kudesia** with numerological alignment:
- **Life Path 4** → Builder energy (creating lasting structures)
- **Expression 1** → Leadership, innovation, pioneering
- **Personality 7** → Wisdom, intuition, analysis
- **Lucky Numbers:** 1, 4, 7, 10, 13, 16, 19, 22, 25

APEX SURGE resonates with these energies through:
- 19→1 (APEX: Leadership expression)
- 25→7 (SURGE: Lucky + Wisdom)
- Combined: 8 (Infinity, manifestation power)

---

## 🚀 Deployment

### Firebase Hosting (Recommended)
```bash
firebase deploy
# Live at: https://apex-surge-[project-id].web.app
```

### Vercel
```bash
vercel deploy
```

### Docker
```bash
docker build -t apex-surge .
docker run -p 3000:3000 apex-surge
```

See `docs/DEPLOYMENT.md` for detailed instructions.

---

## 📖 Documentation

- **[API Reference](docs/API.md)** — Claude prompts & responses
- **[Architecture](docs/ARCHITECTURE.md)** — System design & data flow
- **[Features](docs/FEATURES.md)** — All 8 flows detailed
- **[Deployment](docs/DEPLOYMENT.md)** — Firebase, PWA, mobile setup
- **[Contributing](CONTRIBUTING.md)** — Development guidelines

---

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for:
- Code style guidelines
- PR process
- Issue templates
- Development setup

---

## 📊 Roadmap

**Phase 1 (MVP)** — ✅ All 8 flows, 50 books, Claude integration  
**Phase 2** — Personalized summaries per goal, experiment tracking, daily scoring  
**Phase 3** — Premium subscription, advanced analytics, mobile apps (React Native)  
**Phase 4** — AI-generated experiments, community features, leaderboards  

---

## 📝 License

MIT License — See [LICENSE](LICENSE) file

---

## 👋 About the Creator

**Pooja Kudesia** — AI + Behavior Change Designer  
Building tools that transform knowledge into action.

---

## 📞 Support

- 💬 **Issues:** [GitHub Issues](https://github.com/pooja-kudesia/apex-surge/issues)
- 📧 **Email:** hello@apexsurge.app
- 🌐 **Website:** apexsurge.app

---

**Transform Your Life Across 4 Dimensions. 🚀**

*Career Growth • Personal Growth • Communication • 10X Productivity*
